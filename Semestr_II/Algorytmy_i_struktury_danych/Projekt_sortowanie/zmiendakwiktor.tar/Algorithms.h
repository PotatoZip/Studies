void insert_sort(int *tab, int n);
void selection_sort(int *tab, int n);
void bubble_sort(int *tab, int n);
void quick_sort(int *tab, int p, int n);
void shell_sort(int *tab, int n);
void heap_sort(int *tab, int n);
void heapify(int *tab, int n, int i);
